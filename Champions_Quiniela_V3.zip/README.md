# Champions Quiniela V3

Versión 3 de una aplicación web de quinielas para UEFA Champions League.

## Lo nuevo
- Registro e inicio de sesión.
- Crear múltiples quinielas privadas.
- Código único de invitación y compartir.
- Ranking automático y estadísticas.
- Perfil básico con avatar.
- Partidos por fase y jornada.
- Pronósticos editables hasta el inicio del partido.
- Puntuación: 3 exacto, 1 ganador/empate, 0 fallo.
- Panel de administrador.
- Agregar partidos, ingresar resultados y cerrar partidos.
- Gestión de administradores.
- SQLite para guardar datos.

## Probar
Requiere Node.js 18+.
1. `npm install`
2. `npm start`
3. Abrir `http://localhost:3000`

## Crear el primer administrador
Registra tu cuenta y luego ejecuta en SQLite:
`UPDATE users SET is_admin=1 WHERE email='TU_CORREO';`

## Publicación
Para que amigos entren desde sus celulares hay que desplegar el servidor en un hosting. En producción:
- Cambia JWT_SECRET por una cadena larga y aleatoria.
- Usa HTTPS.
- Para varios servidores, migra SQLite a PostgreSQL.
- Configura backups de la base de datos.

## Nota sobre UEFA
Los nombres/logos oficiales, datos de partidos y marcas de UEFA pueden requerir licencias o fuentes autorizadas si la app se publica comercialmente. Esta versión usa texto y emojis genéricos como placeholders.
