const express=require("express"),path=require("path"),Database=require("better-sqlite3"),bcrypt=require("bcryptjs"),jwt=require("jsonwebtoken"),crypto=require("crypto");
const app=express(),db=new Database("quiniela.db"),SECRET=process.env.JWT_SECRET||"REPLACE_WITH_A_LONG_RANDOM_SECRET";
app.use(express.json());app.use(express.static(path.join(__dirname,"public")));
db.exec(`CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,email TEXT NOT NULL UNIQUE,password TEXT NOT NULL,avatar TEXT DEFAULT '⚽',is_admin INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS pools(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT NOT NULL UNIQUE,owner_id INTEGER NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS members(pool_id INTEGER,user_id INTEGER,UNIQUE(pool_id,user_id));
CREATE TABLE IF NOT EXISTS matches(id INTEGER PRIMARY KEY AUTOINCREMENT,pool_id INTEGER,stage TEXT DEFAULT 'Fase de liga',matchday INTEGER DEFAULT 1,home TEXT NOT NULL,away TEXT NOT NULL,starts_at TEXT NOT NULL,home_score INTEGER,away_score INTEGER,closed INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS predictions(user_id INTEGER,match_id INTEGER,home_score INTEGER,away_score INTEGER,UNIQUE(user_id,match_id));`);

const auth=(req,res,next)=>{try{req.user=jwt.verify((req.headers.authorization||"").replace("Bearer ",""),SECRET);next()}catch(e){res.status(401).json({error:"Sesión no válida"})}};
const admin=(req,res,next)=>req.user?.is_admin?next():res.status(403).json({error:"Solo administrador"});
const sign=u=>jwt.sign({id:u.id,name:u.name,email:u.email,avatar:u.avatar,is_admin:!!u.is_admin},SECRET,{expiresIn:"30d"});
const invite=()=>crypto.randomBytes(4).toString("hex").toUpperCase();

app.post("/api/register",(req,res)=>{try{let {name,email,password,avatar="⚽"}=req.body;if(!name||!email||!password||password.length<6)throw Error();let info=db.prepare("INSERT INTO users(name,email,password,avatar) VALUES(?,?,?,?)").run(name,email.toLowerCase(),bcrypt.hashSync(password,10),avatar);let u=db.prepare("SELECT * FROM users WHERE id=?").get(info.lastInsertRowid);res.json({token:sign(u),user:u})}catch(e){res.status(400).json({error:"Nombre/correo ocupado o datos inválidos"})}});
app.post("/api/login",(req,res)=>{let u=db.prepare("SELECT * FROM users WHERE email=?").get((req.body.email||"").toLowerCase());if(!u||!bcrypt.compareSync(req.body.password||"",u.password))return res.status(401).json({error:"Correo o contraseña incorrectos"});res.json({token:sign(u),user:u})});
app.get("/api/me",auth,(req,res)=>res.json(req.user));

app.get("/api/pools",auth,(req,res)=>res.json(db.prepare("SELECT p.*,COUNT(mb.user_id) members FROM pools p JOIN members mine ON mine.pool_id=p.id LEFT JOIN members mb ON mb.pool_id=p.id WHERE mine.user_id=? GROUP BY p.id ORDER BY p.id DESC").all(req.user.id)));
app.post("/api/pools",auth,(req,res)=>{let name=(req.body.name||"").trim();if(!name)return res.status(400).json({error:"Escribe un nombre"});let c=invite(),i=db.prepare("INSERT INTO pools(name,code,owner_id) VALUES(?,?,?)").run(name,c,req.user.id);db.prepare("INSERT INTO members VALUES(?,?)").run(i.lastInsertRowid,req.user.id);res.json(db.prepare("SELECT * FROM pools WHERE id=?").get(i.lastInsertRowid))});
app.post("/api/pools/join",auth,(req,res)=>{let p=db.prepare("SELECT * FROM pools WHERE code=?").get((req.body.code||"").trim().toUpperCase());if(!p)return res.status(404).json({error:"Código no encontrado"});db.prepare("INSERT OR IGNORE INTO members VALUES(?,?)").run(p.id,req.user.id);res.json(p)});
app.get("/api/pools/:id",auth,(req,res)=>{let p=db.prepare("SELECT * FROM pools WHERE id=?").get(req.params.id);let ok=db.prepare("SELECT 1 FROM members WHERE pool_id=? AND user_id=?").get(req.params.id,req.user.id);if(!p||!ok)return res.status(403).json({error:"Sin acceso"});res.json(p)});

app.get("/api/matches/:pool",auth,(req,res)=>res.json(db.prepare("SELECT * FROM matches WHERE pool_id=? ORDER BY starts_at").all(req.params.pool)));
app.post("/api/predictions",auth,(req,res)=>{let {match_id,home_score,away_score}=req.body,m=db.prepare("SELECT * FROM matches WHERE id=?").get(match_id);if(!m)return res.status(404).json({error:"Partido no encontrado"});if(m.closed||new Date(m.starts_at)<=new Date())return res.status(400).json({error:"Este pronóstico está cerrado"});if(!Number.isInteger(+home_score)||!Number.isInteger(+away_score)||home_score<0||away_score<0)return res.status(400).json({error:"Marcador inválido"});db.prepare(`INSERT INTO predictions VALUES(?,?,?,?) ON CONFLICT(user_id,match_id) DO UPDATE SET home_score=excluded.home_score,away_score=excluded.away_score`).run(req.user.id,match_id,+home_score,+away_score);res.json({ok:true})});
app.get("/api/my-predictions/:pool",auth,(req,res)=>res.json(db.prepare(`SELECT pr.match_id,pr.home_score,pr.away_score FROM predictions pr JOIN matches m ON m.id=pr.match_id WHERE pr.user_id=? AND m.pool_id=?`).all(req.user.id,req.params.pool)));

app.get("/api/ranking/:pool",auth,(req,res)=>{let rows=db.prepare(`SELECT u.id,u.name,u.avatar,
COALESCE(SUM(CASE WHEN m.home_score IS NULL THEN 0 WHEN pr.home_score=m.home_score AND pr.away_score=m.away_score THEN 3
WHEN (pr.home_score=pr.away_score AND m.home_score=m.away_score) OR
(pr.home_score>pr.away_score AND m.home_score>m.away_score) OR
(pr.home_score<pr.away_score AND m.home_score<m.away_score) THEN 1 ELSE 0 END),0) pts,
COUNT(CASE WHEN m.home_score IS NOT NULL THEN 1 END) played
FROM members mb JOIN users u ON u.id=mb.user_id LEFT JOIN predictions pr ON pr.user_id=u.id LEFT JOIN matches m ON m.id=pr.match_id AND m.pool_id=mb.pool_id
WHERE mb.pool_id=? GROUP BY u.id ORDER BY pts DESC,u.name`).all(req.params.pool);res.json(rows.map((r,i)=>({...r,pos:i+1})))});

app.get("/api/stats/:pool",auth,(req,res)=>{let p=req.params.pool;res.json({
participants:db.prepare("SELECT COUNT(*) n FROM members WHERE pool_id=?").get(p).n,
matches:db.prepare("SELECT COUNT(*) n FROM matches WHERE pool_id=?").get(p).n,
finished:db.prepare("SELECT COUNT(*) n FROM matches WHERE pool_id=? AND home_score IS NOT NULL").get(p).n,
predictions:db.prepare("SELECT COUNT(*) n FROM predictions pr JOIN matches m ON m.id=pr.match_id WHERE m.pool_id=?").get(p).n
})});

app.post("/api/admin/matches",auth,admin,(req,res)=>{let {pool_id,stage="Fase de liga",matchday=1,home,away,starts_at}=req.body;if(!pool_id||!home||!away||!starts_at)return res.status(400).json({error:"Faltan datos"});let i=db.prepare("INSERT INTO matches(pool_id,stage,matchday,home,away,starts_at) VALUES(?,?,?,?,?,?)").run(pool_id,stage,matchday,home,away,starts_at);res.json(db.prepare("SELECT * FROM matches WHERE id=?").get(i.lastInsertRowid))});
app.post("/api/admin/results",auth,admin,(req,res)=>{let {match_id,home_score,away_score}=req.body;if(!Number.isInteger(+home_score)||!Number.isInteger(+away_score))return res.status(400).json({error:"Resultado inválido"});db.prepare("UPDATE matches SET home_score=?,away_score=?,closed=1 WHERE id=?").run(+home_score,+away_score,match_id);res.json({ok:true})});
app.post("/api/admin/close",auth,admin,(req,res)=>{db.prepare("UPDATE matches SET closed=1 WHERE id=?").run(req.body.match_id);res.json({ok:true})});
app.get("/api/admin/users",auth,admin,(req,res)=>res.json(db.prepare("SELECT id,name,email,avatar,is_admin FROM users ORDER BY name").all()));
app.post("/api/admin/promote",auth,admin,(req,res)=>{db.prepare("UPDATE users SET is_admin=? WHERE id=?").run(req.body.is_admin?1:0,req.body.id);res.json({ok:true})});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public/index.html")));
app.listen(process.env.PORT||3000,()=>console.log("Champions Quiniela V3: http://localhost:"+(process.env.PORT||3000)));